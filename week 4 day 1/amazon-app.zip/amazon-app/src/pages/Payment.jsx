import { useState } from "react";

function Payment() {

  const [success, setSuccess] =
    useState(false);

  return (
    <div className="container">

      <h1>Payment Page</h1>

      {!success ? (
        <button
          onClick={() =>
            setSuccess(true)
          }
        >
          Place Order
        </button>
      ) : (
        <h2>
            Order Placed Successfully
        </h2>
      )}
    </div>
  );
}

export default Payment;