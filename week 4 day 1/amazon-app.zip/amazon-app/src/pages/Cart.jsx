import { useNavigate } from "react-router-dom";

function Cart({ cart }) {

  const navigate = useNavigate();

  const total = cart.reduce(
    (sum, item) => sum + item.price,
    0
  );

  return (
    <div className="container">

      <h1>My Cart</h1>

      {cart.length === 0 ? (
        <p>Cart is Empty</p>
      ) : (
        <>
          {cart.map((item, index) => (
            <div key={index}>
              <h3>{item.name}</h3>
              <p>₹{item.price}</p>
            </div>
          ))}

          <h2>Total: ₹{total}</h2>

          <button
            onClick={() =>
              navigate("/payment")
            }
          >
            Proceed To Payment
          </button>
        </>
      )}
    </div>
  );
}

export default Cart;