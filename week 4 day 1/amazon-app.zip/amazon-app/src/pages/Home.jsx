import { useState } from "react";

function Home({ cart, setCart }) {

  const [search, setSearch] = useState("");

  const products = [
    {
      id: 1,
      name: "Laptop",
      price: 50000,
    },
    {
      id: 2,
      name: "Phone",
      price: 25000,
    },
    {
      id: 3,
      name: "Headphones",
      price: 3000,
    },
    {
      id: 4,
      name: "Watch",
      price: 5000,
    },
  ];

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div className="container">

      <h1>Home Page</h1>

      <input
        type="text"
        placeholder="Search Product"
        value={search}
        onChange={(e) =>
          setSearch(e.target.value)
        }
      />

      {filteredProducts.map((product) => (
        <div key={product.id}>
          <h3>{product.name}</h3>

          <p>₹{product.price}</p>

          <button
            onClick={() =>
              addToCart(product)
            }
          >
            Add To Cart
          </button>

          <hr />
        </div>
      ))}
    </div>
  );
}

export default Home;