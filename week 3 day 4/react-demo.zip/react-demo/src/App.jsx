import { useEffect, useState } from "react";
import ProductCard from "./ProductCard";

function App() {

  const [products, setProducts] = useState([]);

  useEffect(() => {

    fetch("http://127.0.0.1:8000/products")
      .then((response) => response.json())
      .then((data) => setProducts(data));

  }, []);

  return (
    <div>
      <h1>Product Store</h1>

      {
        products.map((product) => (
          <ProductCard
            key={product.id}
            name={product.name}
            price={product.price}
            image={product.image}
          />
        ))
      }

    </div>
  );
}

export default App;
// import { useState } from "react"
// import Product from "./Product"

// function App() {
//   const [products, setProducts] = useState([
//     { id: 1, name: "Wireless Mouse", price: 1200 },
//     { id: 2, name: "Keyboard", price: 2500 }
//   ])

//   const [name, setName] = useState("")
//   const [price, setPrice] = useState("")

//   function addProduct(event) {
//     event.preventDefault()

//     const newProduct = {
//       id: products.length + 1,
//       name: name,
//       price: price
//     }

//     setProducts([...products, newProduct])

//     setName("")
//     setPrice("")
//   }

//   return (
//     <div>
//       <h1>Product List</h1>

//       <form onSubmit={addProduct}>

//         <input
//           type="text"
//           placeholder="Product name"
//           value={name}
//           onChange={(e) => setName(e.target.value)}
//         />

//         <input
//           type="number"
//           placeholder="Price"
//           value={price}
//           onChange={(e) => setPrice(e.target.value)}
//         />

//         <button type="submit">
//           Add Product
//         </button>

//       </form>

//       {products.map((product) => (
//         <Product
//           key={product.id}
//           name={product.name}
//           price={product.price}
//         />
//       ))}

//     </div>
//   )
// }

// export default App