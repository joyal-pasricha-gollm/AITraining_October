function ProductCard({ name, price, image }) {
  return (
    <div
      style={{
        border: "1px solid gray",
        padding: "15px",
        margin: "10px",
        width: "250px"
      }}
    >
      <img
        src={image}
        alt={name}
        width="200"
      />

      <h2>{name}</h2>

      <h3>₹{price}</h3>
    </div>
  );
}

export default ProductCard;