"""Small FastAPI employee directory, backed by PostgreSQL."""

from contextlib import asynccontextmanager
from datetime import datetime, timezone
import os

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, EmailStr, Field
from sqlalchemy import DateTime, Integer, String, create_engine, select, text
from sqlalchemy.engine import URL
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


# Credentials are supplied by Docker Compose; nothing sensitive lives in React.
database_url = URL.create(
    "postgresql+psycopg",
    username=os.environ.get("DB_USER", "employeeapp"),
    password=os.environ["DB_PASSWORD"],
    host=os.environ.get("DB_HOST", "db"),
    port=int(os.environ.get("DB_PORT", "5432")),
    database=os.environ.get("DB_NAME", "employees"),
)
engine = create_engine(database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)


class Base(DeclarativeBase):
    pass


class Employee(Base):
    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    department: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False
    )


class EmployeeCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    department: str = Field(min_length=2, max_length=100)


class EmployeeResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    email: EmailStr
    department: str
    created_at: datetime


@asynccontextmanager
async def lifespan(app: FastAPI):
    # For this small lab, create the table automatically on first startup.
    # For production projects, use schema migrations such as Alembic.
    Base.metadata.create_all(bind=engine)
    yield
    engine.dispose()


app = FastAPI(title="Employee Directory API", version="1.0.0", lifespan=lifespan, root_path="/api")
# The production browser talks through Nginx on the same origin, so CORS is not needed.
# This narrow localhost origin is only for running a separate local Vite dev server.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Content-Type"],
)


def db_session():
    with SessionLocal() as session:
        yield session


@app.get("/health")
def health():
    return {"service": "fastapi", "status": "ok"}


@app.get("/health/db")
def database_health(session: Session = Depends(db_session)):
    try:
        session.execute(text("SELECT 1"))
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail="Database is unavailable")
    return {"database": "connected", "status": "ok"}


@app.get("/employees", response_model=list[EmployeeResponse])
def list_employees(session: Session = Depends(db_session)):
    return session.scalars(select(Employee).order_by(Employee.id.desc())).all()


@app.post("/employees", response_model=EmployeeResponse, status_code=status.HTTP_201_CREATED)
def add_employee(payload: EmployeeCreate, session: Session = Depends(db_session)):
    employee = Employee(
        name=payload.name.strip(),
        email=str(payload.email).strip().lower(),
        department=payload.department.strip(),
    )
    if len(employee.name) < 2 or len(employee.department) < 2:
        raise HTTPException(status_code=422, detail="Name and department must each have 2+ characters")
    session.add(employee)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        raise HTTPException(status_code=409, detail="An employee with this email already exists")
    session.refresh(employee)
    return employee


@app.delete("/employees/{employee_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_employee(employee_id: int, session: Session = Depends(db_session)):
    employee = session.get(Employee, employee_id)
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")
    session.delete(employee)
    session.commit()
