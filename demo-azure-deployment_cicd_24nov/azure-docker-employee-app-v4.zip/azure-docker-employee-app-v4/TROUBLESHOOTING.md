# Troubleshooting — V4

## White React page

V3's default JSX runtime with no `React` binding could cause a blank page. V4 includes an explicit import and configures Vite `esbuild.jsx = 'automatic'`. Use V4 rather than extracting V3 again.

```bash
cd ~/azure-docker-employee-app-v4
sudo docker compose build --no-cache frontend
sudo docker compose up -d --no-deps frontend
./scripts/check.sh
```

Hard refresh browser. If the app still doesn't render, check Developer Tools -> Console, and `sudo docker compose logs --tail=100 frontend`. HTTP 200 and a healthy Nginx container alone do **not** prove React rendered.

## Backend can't install Python packages (PyPI SSL EOF / read timeout)

V4 uses VM-host `curl -4` with SHA-256 verification to download wheels before Docker builds the backend. Docker then installs offline via `pip --no-index`. The first deployment still requires HTTPS to **both** `pypi.org` and `files.pythonhosted.org`.

```bash
curl -4 -I --max-time 20 https://pypi.org/simple/fastapi/
curl -4 -I --max-time 20 https://files.pythonhosted.org/
```

You may copy a previously downloaded verified V3 wheel cache before `./deploy.sh`:

```bash
cp -a ~/azure-docker-employee-app-v3/backend/wheels/. ~/azure-docker-employee-app-v4/backend/wheels/
```

The cache's SHA-256 digests are rechecked against the lock record. No `.whl` binaries are shipped in the cohort ZIP.

## Existing database volume; deploy won't generate password

This is intentional: PostgreSQL persists the original database password. Reuse the V3 `.env` file to keep records:

```bash
cp ~/azure-docker-employee-app-v3/.env ~/azure-docker-employee-app-v4/.env
chmod 600 ~/azure-docker-employee-app-v4/.env
```

Or to start completely fresh, stop/remove old containers then remove **only** `azure-employee-demo_pgdata` (permanently deletes employee records).

## Port 80 occupied

```bash
sudo docker ps --format 'table {{.Names}}\t{{.Ports}}'
sudo ss -ltnp '( sport = :80 )'
```

Stop the old stack or set `APP_PORT=8080` in `.env` and open port 8080 in Azure NSG if you intentionally need a second app running.

## API health fails

```bash
sudo docker compose ps
sudo docker compose logs --tail=100 backend db
curl -v http://127.0.0.1/api/health/db
```

Do not expose FastAPI port 8000 or PostgreSQL port 5432 on the public network.

## Browser cannot open VM public IP

Ensure Azure VM is running and Azure NSG allows the intended client IP to reach TCP port 80. Confirm host firewall allows port 80, and `sudo docker compose ps` publishes `0.0.0.0:80->80/tcp` for frontend. This lab is HTTP-only: the browser's "Not Secure" label is expected.
