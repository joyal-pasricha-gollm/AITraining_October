import { defineConfig } from 'vite'

// The automatic JSX runtime avoids the "React is not defined" blank-page error.
// No Vite React plugin is required for this small teaching example.
export default defineConfig({
  esbuild: { jsx: 'automatic', jsxImportSource: 'react' },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        rewrite: path => path.replace(/^\/api/, ''),
      },
    },
  },
})
