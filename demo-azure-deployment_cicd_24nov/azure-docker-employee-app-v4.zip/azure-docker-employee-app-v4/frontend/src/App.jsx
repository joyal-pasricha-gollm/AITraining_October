import React, { useEffect, useState } from 'react'

const emptyForm = { name: '', email: '', department: '' }

async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (response.status === 204) return null
  const data = await response.json().catch(() => null)
  if (!response.ok) {
    const detail = data?.detail
    throw new Error(typeof detail === 'string' ? detail : `Request failed (${response.status})`)
  }
  return data
}

export default function App() {
  const [employees, setEmployees] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [dbReady, setDbReady] = useState(false)

  async function refresh() {
    const [rows, health] = await Promise.all([
      api('/employees'),
      api('/health/db'),
    ])
    setEmployees(rows)
    setDbReady(health.database === 'connected')
  }

  useEffect(() => {
    let active = true
    Promise.all([api('/employees'), api('/health/db')])
      .then(([rows, health]) => {
        if (active) {
          setEmployees(rows)
          setDbReady(health.database === 'connected')
        }
      })
      .catch((err) => { if (active) setError(err.message) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])

  async function submit(event) {
    event.preventDefault()
    setError('')
    setNotice('')
    setBusy(true)
    try {
      await api('/employees', { method: 'POST', body: JSON.stringify(form) })
      await refresh()
      setForm(emptyForm)
      setNotice('Employee saved to PostgreSQL successfully.')
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  async function remove(employee) {
    if (!window.confirm(`Delete ${employee.name}?`)) return
    setError('')
    setNotice('')
    setBusy(true)
    try {
      await api(`/employees/${employee.id}`, { method: 'DELETE' })
      await refresh()
      setNotice('Employee removed from PostgreSQL.')
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="page">
      <header className="topbar">
        <div className="brand">
          <div className="brand-icon">E</div>
          <span>Employee Directory</span>
        </div>
        <div className="chip">Azure VM + Docker Compose</div>
      </header>

      <main className="content">
        <section className="intro">
          <div className="eyebrow">THREE-TIER APPLICATION · LIVE DEMO</div>
          <h1>Manage your team, <span>all in one place.</span></h1>
          <p>A working React → FastAPI → PostgreSQL application, running in three Docker containers on a single Azure Linux VM.</p>
        </section>

        <div className="status-row">
          <div className="status-item"><span className="dot green" /> React frontend <strong>Online</strong></div>
          <div className="status-item"><span className={`dot ${dbReady ? 'green' : 'gray'}`} /> FastAPI + PostgreSQL <strong>{dbReady ? 'Connected' : 'Checking'}</strong></div>
          <div className="status-item"><span className="count">{employees.length}</span> Employees</div>
        </div>

        <div className="two-column">
          <section className="panel form-panel">
            <h2>Add employee</h2>
            <p className="subtitle">New employees are saved permanently in PostgreSQL.</p>
            <form onSubmit={submit}>
              <label htmlFor="name">Full name</label>
              <input id="name" placeholder="e.g. Anita Sharma" required minLength={2} maxLength={100}
                value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              <label htmlFor="email">Email address</label>
              <input id="email" type="email" placeholder="anita@example.com" required maxLength={255}
                value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
              <label htmlFor="department">Department</label>
              <input id="department" placeholder="e.g. Engineering" required minLength={2} maxLength={100}
                value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} />
              <button className="primary" type="submit" disabled={busy}>{busy ? 'Working…' : '+ Add employee'}</button>
            </form>
            {error && <div className="alert error" role="alert">{error}</div>}
            {notice && <div className="alert success" role="status">{notice}</div>}
          </section>

          <section className="panel list-panel">
            <div className="panel-heading"><div><h2>Employees</h2><p className="subtitle">Records fetched from the FastAPI backend</p></div><button className="secondary" onClick={() => { setLoading(true); setError(''); refresh().catch(e => setError(e.message)).finally(() => setLoading(false)) }} disabled={loading || busy}>↻ Refresh</button></div>
            {loading ? <div className="empty">Loading records…</div> : employees.length === 0 ? (
              <div className="empty"><div className="empty-icon">◎</div><strong>No employees yet</strong><span>Add the first employee using the form.</span></div>
            ) : (
              <div className="employee-list">{employees.map(employee => (
                <div className="employee" key={employee.id}>
                  <div className="avatar">{employee.name.trim().split(/\s+/).slice(0, 2).map(s => s[0]?.toUpperCase()).join('')}</div>
                  <div className="employee-detail"><strong>{employee.name}</strong><span>{employee.email}</span><small>{employee.department}</small></div>
                  <button className="delete" title={`Delete ${employee.name}`} aria-label={`Delete ${employee.name}`} onClick={() => remove(employee)} disabled={busy}>×</button>
                </div>
              ))}</div>
            )}
          </section>
        </div>

        <footer>
          <span>Frontend: React + Nginx</span><span>API: FastAPI</span><span>Database: PostgreSQL 17</span>
        </footer>
      </main>
    </div>
  )
}
