# Employee Directory — Azure VM + Docker Compose (V4 cohort edition)

Three-tier lab built with **React 19, Vite, Nginx, FastAPI, SQLAlchemy and PostgreSQL 17**. One Azure Ubuntu 24.04 x64 VM runs all three containers.

```text
Browser
   | HTTP :80
Nginx + React (frontend)
   | /api/*  [private Docker network]
FastAPI (backend :8000)
   | PostgreSQL driver [private Docker network]
Postgres (db :5432)
   |
Named Docker volume: azure-employee-demo_pgdata
```

Only the frontend exposes a host port; never expose 8000 or 5432 publicly.

## V4 fixes over V3

1. `frontend/src/App.jsx` explicitly imports React.
2. `frontend/vite.config.js` uses the **automatic JSX runtime**, so JSX does not depend on a missing global `React` variable.
3. `index.html` displays a loading message if JavaScript fails, instead of an unexplained white screen.
4. Nginx has a `/healthz` endpoint and a frontend container healthcheck.
5. The test script verifies API connectivity, PostgreSQL, HTML and compiled frontend JavaScript asset availability. This is **not** a real headless-browser rendering test.
6. The deployment script prevents creation of a new database password when the old PostgreSQL volume already exists.
7. Retains the working IPv4 host curl-based, SHA-256-verified wheel-fetching process from V3; Docker installs Python dependencies offline.

## Hardware and software prerequisites

Ubuntu 24.04 LTS x64, Docker Engine + Compose plugin, curl, openssl, unzip, Python3. Recommended for training: 2 vCPU, 4 GiB RAM, 40–64 GiB SSD. Network: inbound TCP 80 for browser, TCP 22 restricted to your IP; outbound HTTPS 443 to Docker Hub, npm registry, PyPI index and wheel CDN. This is **HTTP-only, unauthenticated**, so use fictional data.

## Deployment

On your Mac or Windows terminal (NOT inside an Azure SSH terminal), upload:

```bash
scp ~/Downloads/azure-docker-employee-app-v4.zip azureuser@YOUR_VM_PUBLIC_IP:~/
```

SSH into the Ubuntu VM, then:

```bash
cd ~
unzip azure-docker-employee-app-v4.zip
cd azure-docker-employee-app-v4
./deploy.sh
./scripts/check.sh
```

If upgrading and the old database volume exists, **before running `./deploy.sh`** copy the existing matching `.env` file:

```bash
cp ~/azure-docker-employee-app-v3/.env .env
chmod 600 .env
```

If the old data is not needed, stop/remove the old containers and remove **only** `azure-employee-demo_pgdata` as shown in `COHORT_QUICKSTART.md`. Volume deletion is irreversible.

The deployment script creates a random `.env` password when a database volume does not already exist. For safety, it refuses to regenerate credentials against an existing PostgreSQL volume.

To save re-downloading existing V3 dependencies, before deploying:

```bash
cp -a ~/azure-docker-employee-app-v3/backend/wheels/. backend/wheels/
```

It checks cached wheel hashes. No third-party wheels are included in the ZIP. On an unprepared VM the first deploy **must** reach PyPI and its wheel CDN over outbound HTTPS. A successful PyPI index test alone does not prove CDN access. The React build also needs npm registry access at least once.

## URLs

- `http://YOUR_VM_PUBLIC_IP/` — React employee management UI
- `http://YOUR_VM_PUBLIC_IP/api/docs` — Swagger UI
- `http://YOUR_VM_PUBLIC_IP/api/health/db` — database connectivity
- `http://YOUR_VM_PUBLIC_IP/healthz` — frontend container check

## Actions

Use the React form to add fictional employees, view records and delete them. FastAPI offers `GET /employees`, `POST /employees`, and `DELETE /employees/{id}` behind the `/api` reverse proxy.

## Useful commands

```bash
sudo docker compose ps
sudo docker compose logs --tail=100 backend
sudo docker compose logs --tail=100 frontend
sudo docker compose up -d --build
sudo docker compose down   # retains the named PostgreSQL volume
```

For a blank page, first hard refresh your browser, then use DevTools **Console**. `./scripts/check.sh` verifies the compiled JS asset exists, but cannot guarantee it executed successfully in the browser. See `TROUBLESHOOTING.md`.

## Database warnings

PostgreSQL data persists in the `azure-employee-demo_pgdata` Docker volume, even if containers are removed. Reuse the matching `.env` to preserve data. `sudo docker volume rm azure-employee-demo_pgdata` deletes the data. Do not use indiscriminate volume pruning.
