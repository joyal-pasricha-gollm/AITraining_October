#!/usr/bin/env python3
"""Download a fixed Linux x86_64 CPython 3.12 wheelhouse via *host* curl IPv4.

Why not pip download? On some Azure VMs pip inside Docker repeatedly suffers
PyPI HTTPS EOF/timeouts even though `curl -4 https://pypi.org/...` works.

This script only uses Python's stdlib and curl -4 (no pip/venv required), obtains
trusted PyPI JSON metadata over HTTPS, verifies each wheel's SHA-256 digest,
and writes all wheels to backend/wheels/ for fully offline Docker pip install.
"""
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "scripts" / "package-versions.json"
REQUIREMENTS = ROOT / "backend" / "requirements.txt"
WHEEL_DIR = ROOT / "backend" / "wheels"
LOCK = WHEEL_DIR / "verified-wheels.json"


def curl(url: str, output: Path | None = None) -> bytes:
    command = [
        "curl", "--ipv4", "--fail", "--location", "--silent", "--show-error",
        "--retry", "4", "--retry-all-errors", "--retry-delay", "2",
        "--connect-timeout", "20", "--max-time", "180",
        "--proto", "=https", "--tlsv1.2",
    ]
    if output is not None:
        command += ["--output", str(output)]
    command.append(url)
    try:
        r = subprocess.run(command, check=True, stdout=subprocess.PIPE if output is None else subprocess.DEVNULL)
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        raise RuntimeError(f"IPv4 curl download failed: {url}\n{exc}") from exc
    return r.stdout or b""


def wheel_priority(filename: str) -> int | None:
    """Select pure Python or CPython 3.12 manylinux x86_64 wheels, not sdists."""
    if not filename.endswith(".whl"):
        return None
    try:
        py, abi, plat = filename[:-4].rsplit("-", 3)[-3:]
    except ValueError:
        return None
    py_tags, abi_tags, platform_tags = py.split("."), abi.split("."), plat.split(".")
    if "any" in platform_tags and "none" in abi_tags and any(t in py_tags for t in ("py3", "py312", "py2.py3")):
        return 100
    if not any(x in py_tags for x in ("cp312", "py3")):
        return None
    if not any(x in abi_tags for x in ("cp312", "abi3")):
        return None
    if not any("x86_64" in x and (x.startswith("manylinux") or x.startswith("linux")) for x in platform_tags):
        return None
    # Do not accept tags requiring a newer glibc than Debian bookworm (2.36).
    matches = re.findall(r"manylinux_(\d+)_(\d+)_x86_64", plat)
    if matches and min(int(v) for major, v in matches if major == "2") > 36:
        return None
    return 30 + (5 if "cp312" in abi_tags else 0) + (2 if "manylinux2014" in plat else 0)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    if platform.system() != "Linux" or platform.machine() != "x86_64":
        print("ERROR: Run on an x86_64 Linux Azure VM (Ubuntu 24.04).", file=sys.stderr)
        return 2
    if not shutil_which("curl"):
        print("ERROR: curl is missing. Run: sudo apt-get install -y curl", file=sys.stderr)
        return 2
    WHEEL_DIR.mkdir(parents=True, exist_ok=True)
    packages: dict[str, str] = json.loads(MANIFEST.read_text())
    fingerprint = hashlib.sha256(MANIFEST.read_bytes() + REQUIREMENTS.read_bytes()).hexdigest()
    if LOCK.exists():
        try:
            last = json.loads(LOCK.read_text())
            if last.get("fingerprint") == fingerprint and len(last.get("packages", [])) == len(packages) and all(
                (WHEEL_DIR / wheel["filename"]).is_file()
                and sha256(WHEEL_DIR / wheel["filename"]) == wheel["sha256"]
                for wheel in last["packages"]
            ):
                print(f"All {len(packages)} SHA-256-verified wheels are cached; no downloads needed.")
                return 0
        except (ValueError, KeyError, OSError):
            pass

    # Remove old unverified wheels to prevent mixing incompatible package versions.
    LOCK.unlink(missing_ok=True)
    for old in WHEEL_DIR.glob("*.whl"):
        old.unlink()

    print("Downloading verified Python wheels using VM curl --ipv4 (NOT pip / Docker build).", flush=True)
    verified = []
    for num, (package, version) in enumerate(packages.items(), start=1):
        print(f"[{num}/{len(packages)}] {package}=={version}", flush=True)
        metadata = json.loads(curl(f"https://pypi.org/pypi/{package}/{version}/json"))
        choices = [(wheel_priority(f["filename"]), f) for f in metadata.get("urls", [])]
        choices = [(p, f) for p, f in choices if p is not None and f.get("packagetype") == "bdist_wheel"]
        if not choices:
            raise RuntimeError(f"No CPython 3.12 Linux x86_64 wheel at PyPI: {package}=={version}")
        info = sorted(choices, key=lambda item: (-item[0], item[1]["filename"]))[0][1]
        filename = info["filename"]
        url = info["url"]
        expected = info["digests"]["sha256"]
        destination = WHEEL_DIR / filename
        part = WHEEL_DIR / (filename + ".partial")
        try:
            curl(url, part)
            actual = sha256(part)
            if actual != expected:
                raise RuntimeError(f"SHA-256 mismatch for {filename}: expected {expected}, got {actual}")
            os.replace(part, destination)
        finally:
            part.unlink(missing_ok=True)
        verified.append({"package": package, "version": version, "filename": filename, "sha256": expected})

    LOCK.write_text(json.dumps({"fingerprint": fingerprint, "packages": verified}, indent=2) + "\n")
    print(f"SUCCESS: {len(verified)} verified wheels ready. Docker will install offline.", flush=True)
    return 0


def shutil_which(name: str):
    from shutil import which
    return which(name)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        print("Hint: Run 'curl -4 -I https://files.pythonhosted.org' to check wheel CDN access.", file=sys.stderr)
        sys.exit(1)
