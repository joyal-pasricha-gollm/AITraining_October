#!/usr/bin/env python3
"""Offline structure/static checks (not a full Docker/browser test)."""
from pathlib import Path
import ast
import json
import re

root = Path(__file__).resolve().parents[1]
assert (root / 'docker-compose.yml').read_text().startswith('name: azure-employee-demo')
assert "jsx: 'automatic'" in (root / 'frontend/vite.config.js').read_text()
assert "import React, { useEffect, useState } from 'react'" in (root / 'frontend/src/App.jsx').read_text()
assert 'proxy_pass http://backend:8000/;' in (root / 'frontend/nginx.conf').read_text()
assert '--no-index' in (root / 'backend/Dockerfile').read_text()
assert 'verified-wheels.json' in (root / 'scripts/fetch_wheels_ipv4.py').read_text()
assert 'volume inspect azure-employee-demo_pgdata' in (root / 'deploy.sh').read_text()
for pyfile in root.rglob('*.py'):
    ast.parse(pyfile.read_text())
for jsonfile in root.rglob('*.json'):
    json.loads(jsonfile.read_text())
print('PASS: package structure, Python syntax, JSON and key deployment constraints')
