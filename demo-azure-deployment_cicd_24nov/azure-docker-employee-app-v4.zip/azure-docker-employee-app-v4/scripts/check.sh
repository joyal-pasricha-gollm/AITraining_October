#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")/.."
if docker info >/dev/null 2>&1; then DC=(docker); else DC=(sudo docker); fi
"${DC[@]}" compose ps
PORT="$(sed -n 's/^APP_PORT=//p' .env | tail -n 1)"
PORT="${PORT:-80}"
url="http://127.0.0.1:${PORT}"
echo "Checking FastAPI -> PostgreSQL: $url/api/health/db"
ready=0
for _ in $(seq 1 30); do
  if curl -fsS --connect-timeout 2 --max-time 5 "$url/api/health/db"; then
    echo; ready=1; break
  fi
  sleep 2
done
if [[ "$ready" -ne 1 ]]; then
  echo 'ERROR: backend/database health failed. Inspect: sudo docker compose logs --tail=100 backend db' >&2
  exit 1
fi
echo "Checking employee REST API..."
curl -fsS --max-time 6 "$url/api/employees" >/dev/null
echo "Checking React's HTML and compiled JavaScript..."
html="$(curl -fsS --max-time 6 "$url/")"
if ! grep -q 'id="root"' <<< "$html"; then
  echo 'ERROR: frontend index.html has no React root' >&2
  exit 1
fi
asset="$(grep -oE 'src="/assets/[^"]+\.js"' <<< "$html" | head -n 1 | cut -d '"' -f 2 || true)"
if [[ -z "$asset" ]]; then
  echo 'ERROR: Vite compiled JavaScript reference not found in frontend HTML' >&2
  exit 1
fi
curl -fsS --max-time 10 "$url$asset" > /dev/null
if [[ "$(curl -fsS "$url/healthz")" != 'ok' ]]; then
  echo 'ERROR: Nginx health check failed' >&2
  exit 1
fi
echo "SUCCESS: API, PostgreSQL, React HTML, compiled JavaScript and Nginx verified."
echo "Open http://YOUR_AZURE_VM_PUBLIC_IP:${PORT}/ and hard-refresh."
echo "NOTE: a real browser test is still required to confirm JavaScript rendering."
