#!/usr/bin/env bash
# One-command lab deployment for Ubuntu 24.04 x86_64 Azure VMs.
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"

for cmd in python3 curl openssl docker; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "ERROR: $cmd not found. Install it before deploying." >&2
    exit 1
  fi
done
if docker info >/dev/null 2>&1; then
  DC=(docker)
else
  DC=(sudo docker)
fi
"${DC[@]}" compose version >/dev/null 2>&1 || {
  echo 'ERROR: Docker Compose plugin is not installed.' >&2
  exit 1
}

if [[ ! -f .env ]]; then
  # A named PostgreSQL volume outlives stopped/removed containers.
  # Never silently generate a different password for an existing database.
  if "${DC[@]}" volume inspect azure-employee-demo_pgdata >/dev/null 2>&1; then
    cat >&2 <<'NOTICE'
ERROR: Existing employee PostgreSQL volume found, but this project has no .env.
To PRESERVE your database, reuse the old password before redeploying:
  cp ~/azure-docker-employee-app-v3/.env .env
  chmod 600 .env
Or, to RESET the lab database (DELETES ALL employee records), run:
  sudo docker volume rm azure-employee-demo_pgdata
Then rerun ./deploy.sh.
NOTICE
    exit 1
  fi
  umask 077
  printf 'DB_PASSWORD=%s\nAPP_PORT=80\n' "$(openssl rand -hex 24)" > .env
  echo 'Created .env with a random PostgreSQL password.'
fi
chmod 600 .env
if ! grep -Eq '^DB_PASSWORD=.+$' .env; then
  echo 'ERROR: .env must contain DB_PASSWORD (see .env.example).' >&2
  exit 1
fi

echo 'Preparing SHA-256 verified dependencies with host curl -4...'
python3 scripts/fetch_wheels_ipv4.py

echo 'Validating Docker Compose configuration...'
"${DC[@]}" compose config --quiet

echo 'Building and starting frontend, backend and PostgreSQL...'
"${DC[@]}" compose up -d --build
"${DC[@]}" compose ps

echo 'Checking app health...'
./scripts/check.sh
