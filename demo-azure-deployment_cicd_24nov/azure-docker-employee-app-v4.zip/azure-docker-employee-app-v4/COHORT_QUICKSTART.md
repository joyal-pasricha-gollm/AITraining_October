# COHORT QUICKSTART — Employee Directory V4

Deploy **React + Nginx / FastAPI / PostgreSQL 17** as three containers on a single Ubuntu 24.04 x64 Azure VM. V4 includes both the `React` import and automatic JSX transformation, fixes the white-screen issue, and preserves the V3 IPv4 wheel downloader.

## Prerequisites

- Ubuntu 24.04 x64 VM: 2 vCPU / 4 GiB RAM, 40–64 GiB disk suggested.
- Docker Engine + Docker Compose plugin. Verify using `sudo docker compose version`.
- Install utilities once: `sudo apt-get update && sudo apt-get install -y curl unzip python3 openssl`.
- Azure network security group: inbound **80** for HTTP test; inbound **22** restricted to your IP. Do NOT expose 8000 or 5432.
- Outbound HTTPS to Docker Hub, npm, pypi.org and files.pythonhosted.org.
- **Demo only:** HTTP and no authentication. Do not enter real personal information.

## Upload from your laptop terminal (not from Ubuntu SSH)

```bash
scp ~/Downloads/azure-docker-employee-app-v4.zip azureuser@YOUR_VM_PUBLIC_IP:~/
```

For password-based SSH, the command will prompt for the VM login password.

## On the Azure VM

```bash
cd ~
unzip azure-docker-employee-app-v4.zip
cd azure-docker-employee-app-v4
```

### If upgrading from an existing V3 database

**Option A: Keep old employee records** by retaining the Docker volume and copying the matching database password:

```bash
cp ~/azure-docker-employee-app-v3/.env .env
chmod 600 .env
```

**Option B: Reset the demo** (delete old employee records) after stopping old containers:

```bash
sudo docker ps -q | xargs -r sudo docker stop
sudo docker ps -aq | xargs -r sudo docker rm
sudo docker volume rm azure-employee-demo_pgdata  # deletes employee records permanently
```

If no old database volume exists, skip both options. The deploy script generates a unique password.

### Deploy

```bash
./deploy.sh
./scripts/check.sh
```

Open `http://YOUR_VM_PUBLIC_IP/` and hard refresh (`Cmd+Shift+R` on Mac, `Ctrl+Shift+R` on Windows).

## How it works

`Browser -> Nginx port 80 -> /api -> FastAPI -> private Docker network -> PostgreSQL volume`

FastAPI + PostgreSQL are not published to the internet. Python dependencies are fetched via host `curl -4`, SHA-256 verified and installed with **offline pip** inside the Docker build. The ZIP **does not include the wheels**.

### Save time if V3 already downloaded wheels

Before `./deploy.sh`, optionally reuse cached verified wheels:

```bash
cp -a ~/azure-docker-employee-app-v3/backend/wheels/. backend/wheels/
```

The downloader checks the hashes before reuse.

## Verify and troubleshoot

```bash
sudo docker compose ps
curl -fsS http://localhost/api/health/db
./scripts/check.sh
sudo docker compose logs --tail=100 frontend
```

The check script confirms HTTP and JavaScript assets, but a final browser rendering check is still necessary. If a white page persists, inspect Developer Tools **Console** for errors.

Stop only this app: `sudo docker compose down` (keeps database volume). Do **not** run `down -v` if keeping records.
