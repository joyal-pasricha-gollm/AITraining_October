import { useEffect, useState } from "react"
import { Link, useParams } from "react-router-dom"
import { DEFAULT_PRODUCT_IMAGE, getProduct, getProducts } from "./api.js"

function Products() {
  const [products, setProducts] = useState([])
  const [error, setError] = useState("")

  useEffect(() => {
    getProducts()
      .then(setProducts)
      .catch((requestError) => setError(requestError.message))
  }, [])

  return (
    <div>
      <h1>Products</h1>
      {error && <p role="alert">{error}</p>}
      {!error && products.length === 0 && <p>Loading products...</p>}
      <div>
        {products.map((product) => (
          <article key={product.id}>
            <Link to={`/products/${product.id}`}>
              <img
                src={product.image || DEFAULT_PRODUCT_IMAGE}
                alt={product.name}
                width="240"
                height="160"
                style={{ objectFit: "cover" }}
              />
              <h2>{product.name}</h2>
            </Link>
            <p>₹{product.price}</p>
          </article>
        ))}
      </div>
    </div>
  )
}

export function ProductDetails() {
  const { id } = useParams()
  const [result, setResult] = useState({ id: null, product: null, error: "" })

  useEffect(() => {
    let active = true
    getProduct(id)
      .then((product) => {
        if (active) setResult({ id, product, error: "" })
      })
      .catch((requestError) => {
        if (active) setResult({ id, product: null, error: requestError.message })
      })

    return () => {
      active = false
    }
  }, [id])

  if (result.id !== id) return <p>Loading product...</p>
  if (result.error) return <p role="alert">{result.error}</p>
  const { product } = result

  return (
    <article>
      <h1>{product.name}</h1>
      <img
        src={product.image || DEFAULT_PRODUCT_IMAGE}
        alt={product.name}
        width="360"
        height="240"
        style={{ objectFit: "cover" }}
      />
      <p>Product ID: {product.id}</p>
      <p>Price: ₹{product.price}</p>
      <Link to={`/products/${product.id}/edit`}>Edit product</Link>
      <br />
      <Link to="/products">Back to products</Link>
    </article>
  )
}

export default Products