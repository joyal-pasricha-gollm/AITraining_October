import { Link } from "react-router-dom"

function Home() {
  return (
    <div>
      <h1>Product Store</h1>
      <p>Browse the catalog or add a product to the collection.</p>
      <p>
        <Link to="/products">Browse products</Link>
        {" | "}
        <Link to="/products/new">Add a product</Link>
      </p>
    </div>
  )
}

export default Home
