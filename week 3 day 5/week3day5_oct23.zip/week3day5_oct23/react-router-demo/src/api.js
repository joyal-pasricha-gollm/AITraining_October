export const DEFAULT_PRODUCT_IMAGE =
  "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1"

const API_BASE_URL = "http://127.0.0.1:8000"

async function request(path, options) {
  const response = await fetch(`${API_BASE_URL}${path}`, options)
  const data = await response.json()

  if (!response.ok) {
    throw new Error(data.detail || "The request could not be completed.")
  }

  return data
}

export function getProducts() {
  return request("/products")
}

export function getProduct(productId) {
  return request(`/products/${productId}`)
}

export function createProduct(product) {
  return request("/products", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product),
  })
}

export function updateProduct(productId, product) {
  return request(`/products/${productId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product),
  })
}