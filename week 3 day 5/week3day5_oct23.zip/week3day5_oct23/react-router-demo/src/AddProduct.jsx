import { useEffect, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import {
  createProduct,
  DEFAULT_PRODUCT_IMAGE,
  getProduct,
  updateProduct,
} from "./api.js"

function AddProduct() {
  const navigate = useNavigate()
  const { id } = useParams()

  const [name, setName] = useState("")
  const [price, setPrice] = useState("")
  const [image, setImage] = useState(DEFAULT_PRODUCT_IMAGE)
  const [error, setError] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [isLoading, setIsLoading] = useState(Boolean(id))

  useEffect(() => {
    if (!id) return

    getProduct(id)
      .then((product) => {
        setName(product.name)
        setPrice(String(product.price))
        setImage(product.image || DEFAULT_PRODUCT_IMAGE)
      })
      .catch((requestError) => setError(requestError.message))
      .finally(() => setIsLoading(false))
  }, [id])

  async function saveProduct(event) {
    event.preventDefault()
    setError("")
    setIsSaving(true)

    try {
      const product = { name, price: Number(price), image }
      const savedProduct = id
        ? await updateProduct(id, product)
        : await createProduct(product)
      navigate(id ? `/products/${savedProduct.id}` : "/products")
    } catch (requestError) {
      setError(requestError.message)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div>
      <h1>{id ? "Edit Product" : "Add Product"}</h1>
      {isLoading ? (
        <p>Loading product...</p>
      ) : (

      <form onSubmit={saveProduct}>
        <input
          type="text"
          placeholder="Product Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />

        <br />

        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          min="0.01"
          step="0.01"
          required
        />

        <br />

        <input
          type="url"
          placeholder="Image URL"
          value={image}
          onChange={(e) => setImage(e.target.value)}
          required
        />

        <br />

        {error && <p role="alert">{error}</p>}
        <button type="submit" disabled={isSaving}>
          {isSaving ? "Saving..." : id ? "Save Changes" : "Save Product"}
        </button>
      </form>
      )}
    </div>
  )
}

export default AddProduct