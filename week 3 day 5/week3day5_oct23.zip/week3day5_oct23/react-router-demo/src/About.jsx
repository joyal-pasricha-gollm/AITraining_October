function About() {
  return (
    <div>
      <h1>About Page</h1>
      <p>This is the About component.</p>
    </div>
  )
}

export default About