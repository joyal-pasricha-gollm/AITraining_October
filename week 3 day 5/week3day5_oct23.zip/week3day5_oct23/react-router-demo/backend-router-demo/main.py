from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI()

DEFAULT_PRODUCT_IMAGE = "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1"

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ProductCreate(BaseModel):
    name: str = Field(min_length=1)
    price: float = Field(gt=0)
    image: str = DEFAULT_PRODUCT_IMAGE


products = {
    1: {
        "id": 1,
        "name": "Wireless Speaker",
        "price": 500,
        "image": DEFAULT_PRODUCT_IMAGE,
    },
    2: {
        "id": 2,
        "name": "Keyboard",
        "price": 800,
        "image": DEFAULT_PRODUCT_IMAGE,
    },
    3: {
        "id": 3,
        "name": "Monitor",
        "price": 12000,
        "image": DEFAULT_PRODUCT_IMAGE,
    }
}


@app.get("/products")
def get_products():
    return list(products.values())


@app.get("/products/{product_id}")
def get_product(product_id: int):
    product = products.get(product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@app.post("/products", status_code=201)
def create_product(product: ProductCreate):
    product_id = max(products, default=0) + 1
    new_product = {"id": product_id, **product.dict()}
    products[product_id] = new_product
    return new_product


@app.put("/products/{product_id}")
def update_product(product_id: int, product: ProductCreate):
    if product_id not in products:
        raise HTTPException(status_code=404, detail="Product not found")

    updated_product = {"id": product_id, **product.dict()}
    products[product_id] = updated_product
    return updated_product